import math
import socket
import ssl
import base64
class Solver:
    def __init__(self):
        self.start = 0
        self.finish = 0
        self.board = []
        self.size = 0

    def get_field(self, i, row):
        is_empty = False
        if i != self.size:
            row = row[:-3]
        if row != "":
            row_list = row.split(" ")
        else:
            is_empty = True
        if not is_empty:
            j = 0
            while j != len(row_list):
                self.board[i][int(row_list[j]) - 1] = int(row_list[j+1])
                j = j + 2

    def search(self):
        parrents = [0 for _ in range(0, self.size)]
        used = [False for _ in range(0, self.size)] # using None as +inf
        distances = [math.inf for _ in range(0, self.size)]
        current = self.start
        distances[current] = 1
        for i in range(self.size):
            v = None
            for j in range(self.size):
                if not used[j] and (v == None or distances[j] < distances[v]):
                    v = j
            if distances[v] == math.inf:
                break
            used[v] = True
            for e in range(self.size):
                if self.board[v][e] != math.inf:
                    if distances[v] * self.board[v][e] < distances[e]:
                        distances[e] = distances[v] * self.board[v][e]
                        parrents[e] = v
        result_path = []
        x = self.finish
        result_path.append(x)
        while x != self.start:
            x = parrents[x]
            result_path.append(x)
        return distances[self.finish], result_path

    def read_and_write(self):
        f = open('in.txt')
        self.size = int(f.readline()[:-1])
        self.board = [[math.inf for _ in range(0, self.size)] for _ in range(0, self.size)]
        for i in range(self.size):
            self.get_field(i, f.readline())
        self.start = int(f.readline()[:-1]) - 1
        self.finish = int(f.readline()) - 1
        f.close()
        g = open("out.txt", "w")
        result, result_path = self.search()
        if result == math.inf:
            g.write("N")
        else:
            g.write("Y" + "\n")
            for x in result_path[::-1]:
                if x != self.finish:
                    g.write(str(x + 1) + " ")
                else:
                    g.write(str(x + 1) + "\n")
            g.write(str(result))


if __name__ == "__main__":
    s = Solver()
    s.read_and_write()