from cx_Freeze import setup, Executable

setup(
    name = "Algoritm",
    version = "0.1",
    description = "ShortestPathFinder",
    executables = [Executable("task.py")]
)
